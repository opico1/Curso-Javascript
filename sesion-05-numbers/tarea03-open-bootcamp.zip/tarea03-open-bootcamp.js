let centimetros = 100;
let metros = 1.86;
let kilogramos = 80.61

let altura = metros.toFixed(1);
console.log(altura);

let peso = kilogramos.toFixed(1)
console.log(kilogramos);

let max_num = "el máximo valor que se puede obtener en Javascript + 1"
console.log(max_num + Number.MAX_VALUE);