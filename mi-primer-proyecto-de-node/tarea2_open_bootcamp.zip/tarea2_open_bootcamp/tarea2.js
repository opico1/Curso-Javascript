const lista = new Array(5);
lista[0] = "Carlos Antonio Opico";
lista[1] = 25;
lista[2] = true;
lista[3] = new Date("January 30 1997");
lista[4] = {
    titulo: "Harry Potter Y la piedra filosofal",
    autor: "J.K. Rowling",
    fehca: new Date("June 26 1997"),
    url: "https://www.amazon.com/-/es/J-K-Rowling/dp/8478884459"
}

console.log(lista)