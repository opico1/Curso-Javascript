//Factorial con while

let num = 10;
let factorial = 1;
let i = 1

while (i <= num) {
    factorial = factorial * i;
    i++
}
console.log(factorial)