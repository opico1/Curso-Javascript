//Factorial con bucle for

let num = 10;
let factorial = 1;
for(let i = 1; i <= num; i++){
    factorial = factorial * i;
}
console.log(factorial);